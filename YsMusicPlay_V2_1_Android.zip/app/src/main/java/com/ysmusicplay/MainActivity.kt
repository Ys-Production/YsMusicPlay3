package com.ysmusicplay

import android.Manifest
import android.content.ComponentName
import android.content.ContentUris
import android.content.pm.PackageManager
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.delay
import java.util.Locale

private val Bg = Color(0xFF101114)
private val Panel = Color(0xFF202127)
private val Accent = Color(0xFFFF8A00)
private val Muted = Color(0xFFAAAAAE)

data class MediaEntry(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val uri: Uri,
    val folder: String,
    val dateAdded: Long,
    val artwork: Uri? = null,
    val video: Boolean = false
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({
            val controller = runCatching { future.get() }.getOrNull()
            if (controller != null) setContent { YsMusicApp(controller) }
            else setContent { ErrorScreen("Tsy afaka nifandray tamin'ny mpilalao. Avereno sokafana ny rindranasa.") }
        }, MoreExecutors.directExecutor())
    }
}

@Composable
private fun ErrorScreen(message: String) {
    MaterialTheme(colorScheme = darkColorScheme()) {
        Box(Modifier.fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
            Text(message, color = Color.White)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun YsMusicApp(player: MediaController) {
    val context = LocalContext.current
    var page by remember { mutableStateOf("Audio") }
    var audioSection by remember { mutableStateOf("Hira") }
    var audio by remember { mutableStateOf(emptyList<MediaEntry>()) }
    var videos by remember { mutableStateOf(emptyList<MediaEntry>()) }
    var current by remember { mutableStateOf<MediaEntry?>(null) }
    var nowPlaying by remember { mutableStateOf(false) }
    var videoScreen by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var showLyrics by remember { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var sortMode by remember { mutableStateOf("Anarana") }
    var scanInfo by remember { mutableStateOf("Miandry alalana hamaky ny rakitra...") }
    var playing by remember { mutableStateOf(false) }
    var duration by remember { mutableLongStateOf(0L) }
    var position by remember { mutableLongStateOf(0L) }
    var shuffle by remember { mutableStateOf(false) }
    var repeatAll by remember { mutableStateOf(false) }
    var lyricsText by remember { mutableStateOf("") }
    var sleepMinutes by remember { mutableIntStateOf(30) }
    var sleepActive by remember { mutableStateOf(false) }
    var eqEnabled by remember { mutableStateOf(false) }
    var bassEnabled by remember { mutableStateOf(false) }
    var equalizer by remember { mutableStateOf<Equalizer?>(null) }
    var bassBoost by remember { mutableStateOf<BassBoost?>(null) }

    fun scanLibrary() {
        val foundAudio = mutableListOf<MediaEntry>()
        val foundVideo = mutableListOf<MediaEntry>()
        runCatching {
            val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val projection = arrayOf(
                MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.DATE_ADDED, MediaStore.Audio.Media.ALBUM_ID
            )
            context.contentResolver.query(collection, projection, null, null,
                "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
                val idI = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleI = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistI = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumI = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationI = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val dataI = c.getColumnIndex(MediaStore.Audio.Media.DATA)
                val dateI = c.getColumnIndex(MediaStore.Audio.Media.DATE_ADDED)
                val albumIdI = c.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)
                while (c.moveToNext()) {
                    val id = c.getLong(idI)
                    val path = if (dataI >= 0) c.getString(dataI).orEmpty() else ""
                    val albumId = if (albumIdI >= 0) c.getLong(albumIdI) else -1L
                    val art = if (albumId > 0) Uri.parse("content://media/external/audio/albumart/$albumId") else null
                    foundAudio += MediaEntry(
                        id, c.getString(titleI) ?: "Hira tsy fantatra",
                        c.getString(artistI) ?: "Mpanakanto tsy fantatra",
                        c.getString(albumI) ?: "Rakikira tsy fantatra",
                        c.getLong(durationI),
                        ContentUris.withAppendedId(collection, id),
                        path.substringBeforeLast("/", "Music"),
                        if (dateI >= 0) c.getLong(dateI) else 0L, art
                    )
                }
            }
        }.onFailure { scanInfo = "Tsy nahomby ny famakiana hira: ${it.message ?: "hadisoana"}" }

        runCatching {
            val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.TITLE,
                MediaStore.Video.Media.DURATION, MediaStore.Video.Media.DATA, MediaStore.Video.Media.DATE_ADDED)
            context.contentResolver.query(collection, projection, null, null,
                "${MediaStore.Video.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
                val idI = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val titleI = c.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                val durI = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val dataI = c.getColumnIndex(MediaStore.Video.Media.DATA)
                val dateI = c.getColumnIndex(MediaStore.Video.Media.DATE_ADDED)
                while (c.moveToNext()) {
                    val id = c.getLong(idI)
                    val path = if (dataI >= 0) c.getString(dataI).orEmpty() else ""
                    foundVideo += MediaEntry(id, c.getString(titleI) ?: "Video", "", "",
                        c.getLong(durI), ContentUris.withAppendedId(collection, id),
                        path.substringBeforeLast("/", "Videos"),
                        if (dateI >= 0) c.getLong(dateI) else 0L, video = true)
                }
            }
        }.onFailure { scanInfo = "Tsy nahomby ny famakiana vidéo: ${it.message ?: "hadisoana"}" }

        audio = foundAudio
        videos = foundVideo
        scanInfo = "${audio.size} hira sy ${videos.size} vidéo hita."
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants.values.any { it }) scanLibrary()
        else scanInfo = "Tsy nomena alalana hamaky ny rakitra. Jereo ny Fahazoan-dalana ao amin'ny fikirana Android."
    }

    fun requestLibraryAccess() {
        val permissions = when {
            Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO)
            else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) scanLibrary() else permissionLauncher.launch(missing.toTypedArray())
    }

    fun playEntry(entry: MediaEntry, list: List<MediaEntry>) {
        val ordered = list
        val index = ordered.indexOfFirst { it.id == entry.id && it.video == entry.video }.coerceAtLeast(0)
        val items = ordered.map { e ->
            val metadata = MediaMetadata.Builder()
                .setTitle(e.title).setArtist(e.artist)
                .setAlbumTitle(e.album)
                .apply { e.artwork?.let { setArtworkUri(it) } }
                .build()
            MediaItem.Builder().setUri(e.uri).setMediaMetadata(metadata).build()
        }
        player.setMediaItems(items, index, 0L)
        player.shuffleModeEnabled = shuffle
        player.repeatMode = if (repeatAll) Player.REPEAT_MODE_ALL else Player.REPEAT_MODE_OFF
        player.prepare()
        player.play()
        current = entry
        nowPlaying = !entry.video
        videoScreen = entry.video
    }

    LaunchedEffect(Unit) { requestLibraryAccess() }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val title = mediaItem?.mediaMetadata?.title?.toString().orEmpty()
                val artist = mediaItem?.mediaMetadata?.artist?.toString().orEmpty()
                current = (if (videoScreen) videos else audio).firstOrNull { it.title == title && (it.video == videoScreen) }
                    ?: current?.copy(title = title, artist = artist)
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            runCatching { equalizer?.release() }
            runCatching { bassBoost?.release() }
        }
    }
    LaunchedEffect(player) {
        while (true) {
            playing = player.isPlaying
            duration = player.duration.takeIf { it > 0 && it != androidx.media3.common.C.TIME_UNSET } ?: (current?.duration ?: 0L)
            position = player.currentPosition.coerceAtLeast(0L)
            delay(400)
        }
    }
    LaunchedEffect(sleepActive, sleepMinutes) {
        if (sleepActive) {
            delay(sleepMinutes * 60_000L)
            player.pause()
            sleepActive = false
        }
    }

    val filteredAudio = audio.filter {
        val q = search.trim().lowercase(Locale.ROOT)
        q.isEmpty() || it.title.lowercase(Locale.ROOT).contains(q) ||
            it.artist.lowercase(Locale.ROOT).contains(q) || it.album.lowercase(Locale.ROOT).contains(q)
    }
    val sortedAudio = when (sortMode) {
        "Daty" -> filteredAudio.sortedByDescending { it.dateAdded }
        "Faharetana" -> filteredAudio.sortedByDescending { it.duration }
        else -> filteredAudio.sortedBy { it.title.lowercase(Locale.ROOT) }
    }
    val filteredVideos = videos.filter { it.title.contains(search, true) || it.folder.contains(search, true) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent, secondary = Accent, background = Bg, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                if (!nowPlaying && !videoScreen) {
                    Column {
                        if (current != null && player.currentMediaItem != null) {
                            MiniPlayer(current!!, playing,
                                onOpen = { if (current!!.video) videoScreen = true else nowPlaying = true },
                                onPlay = { if (playing) player.pause() else player.play() },
                                onNext = { player.seekToNextMediaItem() })
                        }
                        NavigationBar(containerColor = Color(0xFF17181D)) {
                            listOf("Audio", "Video", "Fikirana").forEach { item ->
                                NavigationBarItem(
                                    selected = page == item, onClick = { page = item },
                                    icon = { Icon(when(item) {
                                        "Audio" -> Icons.Default.MusicNote
                                        "Video" -> Icons.Default.VideoLibrary
                                        else -> Icons.Default.Tune
                                    }, null) },
                                    label = { Text(item) }
                                )
                            }
                        }
                    }
                }
            }
        ) { padding ->
            when {
                nowPlaying -> NowPlayingScreen(
                    current = current, player = player, playing = playing,
                    position = position, duration = duration,
                    onBack = { nowPlaying = false }, onQueue = { showQueue = true },
                    onLyrics = { showLyrics = true }, onSettings = { page = "Fikirana"; nowPlaying = false },
                    onShuffle = { shuffle = !shuffle; player.shuffleModeEnabled = shuffle },
                    shuffle = shuffle,
                    onRepeat = { repeatAll = !repeatAll; player.repeatMode = if (repeatAll) Player.REPEAT_MODE_ALL else Player.REPEAT_MODE_OFF },
                    repeatAll = repeatAll
                )
                videoScreen -> VideoPlayerScreen(
                    player = player, title = current?.title ?: "Video",
                    onBack = { videoScreen = false }, position = position, duration = duration
                )
                else -> Column(Modifier.fillMaxSize().padding(padding)) {
                    Header(onRefresh = { requestLibraryAccess() }, onAbout = { showAbout = true })
                    when (page) {
                        "Audio" -> {
                            Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                listOf("Hira", "Rakikira", "Mpanakanto").forEach { label ->
                                    FilterChip(selected = audioSection == label, onClick = { audioSection = label }, label = { Text(label) })
                                }
                            }
                            OutlinedTextField(
                                value = search, onValueChange = { search = it },
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                                placeholder = { Text("Mitady hira, mpihira, rakikira...") },
                                leadingIcon = { Icon(Icons.Default.Search, null) },
                                singleLine = true
                            )
                            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("Alahatra:", color = Muted, fontSize = 12.sp)
                                listOf("Anarana", "Daty", "Faharetana").forEach { mode ->
                                    TextButton(onClick = { sortMode = mode }) {
                                        Text(mode, color = if (sortMode == mode) Accent else Muted, fontSize = 12.sp)
                                    }
                                }
                            }
                            when (audioSection) {
                                "Rakikira" -> MediaList(sortedAudio.distinctBy { it.album }, true, onClick = { playEntry(it, sortedAudio) })
                                "Mpanakanto" -> MediaList(sortedAudio.distinctBy { it.artist }, false, onClick = { playEntry(it, sortedAudio) })
                                else -> MediaList(sortedAudio, false, onClick = { playEntry(it, sortedAudio) })
                            }
                            Text(scanInfo, color = Muted, fontSize = 10.sp, modifier = Modifier.padding(8.dp))
                        }
                        "Video" -> {
                            OutlinedTextField(value = search, onValueChange = { search = it },
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                                placeholder = { Text("Mitady vidéo na dossier...") }, singleLine = true)
                            MediaList(filteredVideos, false, onClick = { playEntry(it, filteredVideos) }, video = true)
                            Text(scanInfo, color = Muted, fontSize = 10.sp, modifier = Modifier.padding(8.dp))
                        }
                        else -> SettingsScreen(
                            sleepMinutes = sleepMinutes, sleepActive = sleepActive,
                            onSleep = { sleepMinutes = it; sleepActive = false },
                            onStartSleep = { sleepActive = true }, onCancelSleep = { sleepActive = false },
                            eqEnabled = eqEnabled, bassEnabled = bassEnabled,
                            onEq = { enabled ->
                                eqEnabled = enabled
                                runCatching {
                                    if (equalizer == null && player.audioSessionId > 0) equalizer = Equalizer(0, player.audioSessionId)
                                    equalizer?.enabled = enabled
                                }
                            },
                            onBass = { enabled ->
                                bassEnabled = enabled
                                runCatching {
                                    if (bassBoost == null && player.audioSessionId > 0) bassBoost = BassBoost(0, player.audioSessionId)
                                    bassBoost?.setStrength(if (enabled) 700.toShort() else 0.toShort())
                                    bassBoost?.enabled = enabled
                                }
                            },
                            onAbout = { showAbout = true }
                        )
                    }
                }
            }
        }
    }

    if (showQueue) AlertDialog(
        onDismissRequest = { showQueue = false },
        title = { Text("Filaharan-kira") },
        text = {
            Column(Modifier.heightIn(max = 420.dp)) {
                val list = (0 until player.mediaItemCount).mapNotNull { i ->
                    player.getMediaItemAt(i).mediaMetadata.title?.toString()?.let { it to i }
                }
                LazyColumn {
                    items(list) { (title, index) ->
                        ListItem(headlineContent = { Text(title) },
                            supportingContent = { Text(if (index == player.currentMediaItemIndex) "Mandeha izao" else "Manaraka") },
                            modifier = Modifier.clickable { player.seekTo(index); player.play(); showQueue = false },
                            colors = ListItemDefaults.colors(containerColor = Panel))
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { showQueue = false }) { Text("Hidio") } }
    )
    if (showLyrics) AlertDialog(
        onDismissRequest = { showLyrics = false },
        title = { Text("Tononkira") },
        text = {
            OutlinedTextField(value = lyricsText, onValueChange = { lyricsText = it },
                modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp), placeholder = { Text("Ampidiro eto ny tononkira...") })
        },
        confirmButton = { TextButton(onClick = { showLyrics = false }) { Text("Vita") } }
    )
    if (showAbout) AlertDialog(
        onDismissRequest = { showAbout = false },
        title = { Text("Ys Music Play") },
        text = { Column {
            Text("Kinova 2.1")
            Text("Mpamorona: Haritiana")
            Text("Studio: Ys Production")
            Text("WhatsApp: +261 33 95 146 95")
        } },
        confirmButton = { TextButton(onClick = { showAbout = false }) { Text("Hidio") } }
    )
}

@Composable
private fun Header(onRefresh: () -> Unit, onAbout: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.GraphicEq, null, tint = Accent, modifier = Modifier.size(34.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("YS MUSIC PLAY", fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            Text("Ys Production", color = Muted, fontSize = 11.sp)
        }
        IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, "Havaozy") }
        IconButton(onClick = onAbout) { Icon(Icons.Default.Info, "Mombamomba") }
    }
}

@Composable
private fun MediaList(entries: List<MediaEntry>, showAlbum: Boolean, onClick: (MediaEntry) -> Unit, video: Boolean = false) {
    LazyColumn(Modifier.fillMaxSize()) {
        items(entries, key = { "${it.video}-${it.id}" }) { entry ->
            ListItem(
                headlineContent = { Text(if (showAlbum) entry.album else entry.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                supportingContent = {
                    Text(if (video) "${entry.folder} • ${formatTime(entry.duration)}"
                    else "${entry.artist} • ${entry.album} • ${formatTime(entry.duration)}",
                        color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                },
                leadingContent = { Icon(if (video) Icons.Default.VideoFile else Icons.Default.MusicNote, null, tint = Accent) },
                trailingContent = { Icon(Icons.Default.MoreVert, null, tint = Muted) },
                modifier = Modifier.clickable { onClick(entry) },
                colors = ListItemDefaults.colors(containerColor = Bg)
            )
            HorizontalDivider(color = Panel)
        }
    }
}

@Composable
private fun MiniPlayer(entry: MediaEntry, playing: Boolean, onOpen: () -> Unit, onPlay: () -> Unit, onNext: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel).clickable { onOpen() }.padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(if (entry.video) Icons.Default.VideoFile else Icons.Default.MusicNote, null, tint = Accent, modifier = Modifier.size(34.dp))
        Column(Modifier.weight(1f).padding(start = 10.dp)) {
            Text(entry.title, maxLines = 1, fontWeight = FontWeight.SemiBold)
            Text(entry.artist, color = Muted, fontSize = 11.sp)
        }
        IconButton(onClick = onPlay) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null) }
        IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, null) }
    }
}

@Composable
private fun NowPlayingScreen(
    current: MediaEntry?, player: MediaController, playing: Boolean, position: Long, duration: Long,
    onBack: () -> Unit, onQueue: () -> Unit, onLyrics: () -> Unit, onSettings: () -> Unit,
    onShuffle: () -> Unit, shuffle: Boolean, onRepeat: () -> Unit, repeatAll: Boolean
) {
    Column(Modifier.fillMaxSize().background(Bg).padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.KeyboardArrowDown, "Miverina") }
            Text("Mandeha izao", Modifier.weight(1f), fontWeight = FontWeight.Bold)
            IconButton(onClick = onQueue) { Icon(Icons.Default.QueueMusic, "Filaharana") }
            IconButton(onClick = onSettings) { Icon(Icons.Default.Tune, "Fikirana") }
        }
        Spacer(Modifier.weight(1f))
        Box(Modifier.fillMaxWidth().weight(3f).background(Panel, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
            if (current?.artwork != null) {
                AsyncImage(
                    model = current.artwork,
                    contentDescription = "Sary fonon-kira",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(Icons.Default.Album, null, tint = Accent, modifier = Modifier.size(130.dp))
            }
        }
        Spacer(Modifier.height(24.dp))
        Text(current?.title ?: "Hira", fontSize = 23.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(current?.artist ?: "", color = Muted)
        Spacer(Modifier.height(18.dp))
        Slider(value = position.toFloat().coerceIn(0f, duration.coerceAtLeast(1).toFloat()),
            onValueChange = { player.seekTo(it.toLong()) }, valueRange = 0f..duration.coerceAtLeast(1).toFloat())
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(position), color = Muted, fontSize = 12.sp)
            Text(formatTime(duration), color = Muted, fontSize = 12.sp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onShuffle) { Icon(Icons.Default.Shuffle, null, tint = if (shuffle) Accent else Muted) }
            IconButton(onClick = { player.seekToPreviousMediaItem() }) { Icon(Icons.Default.SkipPrevious, null) }
            FilledIconButton(onClick = { if (playing) player.pause() else player.play() }, modifier = Modifier.size(64.dp)) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null)
            }
            IconButton(onClick = { player.seekToNextMediaItem() }) { Icon(Icons.Default.SkipNext, null) }
            IconButton(onClick = onRepeat) { Icon(Icons.Default.Repeat, null, tint = if (repeatAll) Accent else Muted) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onLyrics) { Icon(Icons.Default.Lyrics, null); Spacer(Modifier.width(5.dp)); Text("Tononkira") }
            OutlinedButton(onClick = onQueue) { Icon(Icons.Default.QueueMusic, null); Spacer(Modifier.width(5.dp)); Text("Filaharana") }
        }
        Spacer(Modifier.weight(1f))
    }
}

@Composable
private fun VideoPlayerScreen(player: MediaController, title: String, onBack: () -> Unit, position: Long, duration: Long) {
    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Text(title, color = Color.White, maxLines = 1, modifier = Modifier.weight(1f))
        }
        AndroidView(factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
            update = { it.player = player },
            modifier = Modifier.fillMaxWidth().weight(1f))
        Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(position), color = Color.White)
            Text(formatTime(duration), color = Color.White)
        }
    }
}

@Composable
private fun SettingsScreen(
    sleepMinutes: Int, sleepActive: Boolean, onSleep: (Int) -> Unit, onStartSleep: () -> Unit, onCancelSleep: () -> Unit,
    eqEnabled: Boolean, bassEnabled: Boolean, onEq: (Boolean) -> Unit, onBass: (Boolean) -> Unit, onAbout: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("FIKIRANA", color = Accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        SettingSwitch("Equalizer", eqEnabled, onEq)
        SettingSwitch("Bass Booster", bassEnabled, onBass)
        Spacer(Modifier.height(14.dp))
        Text("FAMARANANA AUTOMATIKA", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            listOf(15, 30, 45, 60).forEach { n ->
                FilterChip(selected = sleepMinutes == n, onClick = { onSleep(n) }, label = { Text("$n min") })
            }
        }
        Button(onClick = onStartSleep, modifier = Modifier.padding(top = 8.dp)) { Text("Alefaso ny Sleep Timer") }
        TextButton(onClick = onCancelSleep) { Text("Atsaharo ny timer") }
        if (sleepActive) Text("Hijanona afaka $sleepMinutes minitra", color = Accent)
        Spacer(Modifier.height(18.dp))
        TextButton(onClick = onAbout) { Icon(Icons.Default.Info, null); Spacer(Modifier.width(6.dp)); Text("Mombamomba ny rindranasa") }
        Text("Ny fisian'ny Equalizer sy Bass Booster dia miankina amin'ny fanohanan'ny finday.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked, onCheckedChange = onChange)
    }
}

private fun formatTime(ms: Long): String {
    if (ms <= 0) return "0:00"
    val sec = ms / 1000
    return "%d:%02d".format(sec / 60, sec % 60)
}
